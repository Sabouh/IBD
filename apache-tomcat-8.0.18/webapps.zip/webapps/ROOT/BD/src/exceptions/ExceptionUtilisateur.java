package exceptions;

public class ExceptionUtilisateur extends ExceptionTheatre {

	public ExceptionUtilisateur() {
		// TODO Auto-generated constructor stub
	}

	public ExceptionUtilisateur(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public ExceptionUtilisateur(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public ExceptionUtilisateur(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

}
